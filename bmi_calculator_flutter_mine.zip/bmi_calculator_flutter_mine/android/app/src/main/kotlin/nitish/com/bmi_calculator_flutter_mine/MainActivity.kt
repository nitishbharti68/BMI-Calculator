package nitish.com.bmi_calculator_flutter_mine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
